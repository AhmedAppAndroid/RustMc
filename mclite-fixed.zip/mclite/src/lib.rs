//! MC Lite core: Mojang manifest -> files on disk -> JVM command line.
//! Works for any version in the manifest (26.1, 26.3, ...): nothing is hardcoded.
use anyhow::{anyhow, ensure, Result};
use jni::{objects::{JObject, JString}, sys::jint, JNIEnv};
use rayon::prelude::*;
use serde::Deserialize;
use sha1::{Digest, Sha1};
use std::{fs, io::Read, path::{Path, PathBuf}};

const MANIFEST: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
const ASSETS: &str = "https://resources.download.minecraft.net";

#[derive(Deserialize)] struct Manifest { versions: Vec<Entry> }
#[derive(Deserialize)] pub struct Entry { pub id: String, pub url: String }
#[derive(Deserialize)] struct Artifact { url: String, sha1: String, path: Option<String> }
#[derive(Deserialize)] struct LibDl { artifact: Option<Artifact> }
#[derive(Deserialize)] struct RuleOs { name: Option<String> }
#[derive(Deserialize)] struct Rule { action: String, os: Option<RuleOs> }
#[derive(Deserialize)] struct Library { downloads: Option<LibDl>, rules: Option<Vec<Rule>> }
#[derive(Deserialize)] struct IndexRef { id: String, url: String, sha1: String }
#[derive(Deserialize)] struct Client { url: String, sha1: String }
#[derive(Deserialize)] struct Downloads { client: Client }
#[derive(Deserialize)] struct Java { #[serde(rename = "majorVersion")] major: u32 }
#[derive(Deserialize)] struct Args { game: Vec<serde_json::Value>, jvm: Vec<serde_json::Value> }
#[derive(Deserialize)]
struct VersionJson {
    #[serde(rename = "mainClass")] main_class: String,
    #[serde(rename = "assetIndex")] asset_index: IndexRef,
    #[serde(rename = "javaVersion")] java: Option<Java>,
    libraries: Vec<Library>,
    downloads: Downloads,
    arguments: Args,
}

/// Filled in by a real Microsoft login (you need to own the game).
pub struct Auth { pub name: String, pub uuid: String, pub token: String }
pub struct Prepared { pub java_major: u32, pub cmd: Vec<String> }

fn get(url: &str) -> Result<Vec<u8>> {
    let mut buf = Vec::new();
    ureq::get(url).call()?.into_reader().read_to_end(&mut buf)?;
    Ok(buf)
}

fn fetch(url: &str, sha1: &str, dest: &Path) -> Result<()> {
    if let Ok(b) = fs::read(dest) {
        if hex::encode(Sha1::digest(&b)) == sha1 { return Ok(()); }
    }
    let b = get(url)?;
    ensure!(hex::encode(Sha1::digest(&b)) == sha1, "bad sha1 for {url}");
    if let Some(p) = dest.parent() { fs::create_dir_all(p)?; }
    fs::write(dest, b)?;
    Ok(())
}

pub fn versions() -> Result<Vec<Entry>> {
    Ok(serde_json::from_slice::<Manifest>(&get(MANIFEST)?)?.versions)
}

fn allowed(rules: &Option<Vec<Rule>>) -> bool {
    let Some(rules) = rules else { return true };
    let mut ok = false;
    for r in rules {
        let hit = r.os.as_ref().and_then(|o| o.name.as_deref()).map_or(true, |n| n == "linux");
        if hit { ok = r.action == "allow"; }
    }
    ok
}

/// Low-end phone JVM flags (Itel A70 class). Tune after benchmarking.
fn jvm_flags() -> Vec<String> {
    ["-Xms512M", "-Xmx1536M", "-XX:+UseSerialGC", "-Xss1M", "-Dfile.encoding=UTF-8"]
        .map(String::from).to_vec()
}

/// Writes the 100-FPS profile into options.txt (merges, keeps your other settings).
/// Key names follow recent Java options.txt; check them against your version.
pub fn apply_fps_profile(root: &Path, fps: u32) -> Result<()> {
    let want = [
        ("maxFps", fps.to_string()), ("enableVsync", "false".into()),
        ("renderDistance", "4".into()), ("simulationDistance", "5".into()),
        ("particles", "2".into()), ("entityDistanceScaling", "0.5".into()),
        ("biomeBlendRadius", "0".into()), ("mipmapLevels", "0".into()),
        ("entityShadows", "false".into()),
    ];
    fs::create_dir_all(root)?;
    let path = root.join("options.txt");
    let old = fs::read_to_string(&path).unwrap_or_default();
    let mut lines: Vec<String> = old.lines()
        .filter(|l| !want.iter().any(|(k, _)| l.starts_with(&format!("{k}:"))))
        .map(String::from).collect();
    lines.extend(want.iter().map(|(k, v)| format!("{k}:{v}")));
    fs::write(path, lines.join("\n") + "\n")?;
    Ok(())
}

pub fn prepare(id: &str, root: &Path, auth: &Auth) -> Result<Prepared> {
    let entry = versions()?.into_iter().find(|e| e.id == id)
        .ok_or_else(|| anyhow!("version {id} is not in Mojang's manifest"))?;
    let v: VersionJson = serde_json::from_slice(&get(&entry.url)?)?;

    let client = root.join(format!("versions/{id}/{id}.jar"));
    fetch(&v.downloads.client.url, &v.downloads.client.sha1, &client)?;

    let mut cp: Vec<PathBuf> = Vec::new();
    for l in v.libraries.iter().filter(|l| allowed(&l.rules)) {
        if let Some(a) = l.downloads.as_ref().and_then(|d| d.artifact.as_ref()) {
            let p = root.join("libraries").join(a.path.clone().unwrap_or_default());
            fetch(&a.url, &a.sha1, &p)?;
            cp.push(p);
        }
    }
    cp.push(client);

    let idx_path = root.join(format!("assets/indexes/{}.json", v.asset_index.id));
    fetch(&v.asset_index.url, &v.asset_index.sha1, &idx_path)?;
    let idx: serde_json::Value = serde_json::from_slice(&fs::read(&idx_path)?)?;
    let hashes: Vec<String> = idx["objects"].as_object().map(|o| {
        o.values().filter_map(|x| x["hash"].as_str().map(String::from)).collect()
    }).unwrap_or_default();
    hashes.par_iter().try_for_each(|h| {
        let pre = &h[..2];
        fetch(&format!("{ASSETS}/{pre}/{h}"), h, &root.join(format!("assets/objects/{pre}/{h}")))
    })?;

    let cp_str = cp.iter().map(|p| p.display().to_string()).collect::<Vec<_>>().join(":");
    let vars: Vec<(&str, String)> = vec![
        ("${natives_directory}", root.join("natives").display().to_string()),
        ("${launcher_name}", "MCLite".into()), ("${launcher_version}", "0.1".into()),
        ("${classpath}", cp_str), ("${version_name}", id.into()),
        ("${game_directory}", root.display().to_string()),
        ("${assets_root}", root.join("assets").display().to_string()),
        ("${assets_index_name}", v.asset_index.id.clone()), ("${version_type}", "release".into()),
        ("${auth_player_name}", auth.name.clone()), ("${auth_uuid}", auth.uuid.clone()),
        ("${auth_access_token}", auth.token.clone()), ("${user_type}", "msa".into()),
        ("${clientid}", String::new()), ("${auth_xuid}", String::new()),
    ];
    let sub = |s: String| vars.iter().fold(s, |s, (k, val)| s.replace(k, val));
    let strs = |a: &[serde_json::Value]| -> Vec<String> {
        a.iter().filter_map(|x| x.as_str().map(String::from)).collect() // skips rule objects
    };

    let mut cmd = jvm_flags();
    cmd.extend(strs(&v.arguments.jvm).into_iter().map(|s| sub(s)));
    cmd.push(v.main_class.clone());
    cmd.extend(strs(&v.arguments.game).into_iter().map(|s| sub(s)));
    Ok(Prepared { java_major: v.java.map_or(21, |j| j.major), cmd })
}

/// Easter eggs: tap the cat logo, pick versions, pick the 100 FPS boost.
pub fn easter_egg(taps: u32, version: &str, fps: u32) -> Option<&'static str> {
    match taps {
        3 if fps == 100 => Some("100 FPS on an Itel A70? Challenge accepted."),
        5 if version == "26.3" => Some("26.3: the cats approve."),
        7 => Some("Meow mode unlocked."),
        17 => Some("CATOS 17 Virtual Master Edition: secret skin unlocked."),
        _ => None,
    }
}

// ---- JNI: dev.catos.mclite.Core ----
fn jstr(env: &mut JNIEnv, j: &JString) -> String {
    env.get_string(j).map(|s| s.into()).unwrap_or_default()
}

#[no_mangle]
pub extern "system" fn Java_dev_catos_mclite_Core_prepare<'l>(
    mut env: JNIEnv<'l>, _this: JObject<'l>, version: JString<'l>, root: JString<'l>,
    name: JString<'l>, uuid: JString<'l>, token: JString<'l>, fps: jint,
) -> JString<'l> {
    let (v, r) = (jstr(&mut env, &version), jstr(&mut env, &root));
    let auth = Auth { name: jstr(&mut env, &name), uuid: jstr(&mut env, &uuid), token: jstr(&mut env, &token) };
    let out = (|| -> Result<String> {
        let root = PathBuf::from(&r);
        if fps > 0 { apply_fps_profile(&root, fps as u32)?; }
        let p = prepare(&v, &root, &auth)?;
        Ok(format!("{}\n{}", p.java_major, p.cmd.join("\n")))
    })().unwrap_or_else(|e| format!("ERR\n{e}"));
    env.new_string(out).unwrap()
}

#[no_mangle]
pub extern "system" fn Java_dev_catos_mclite_Core_egg<'l>(
    mut env: JNIEnv<'l>, _this: JObject<'l>, taps: jint, version: JString<'l>, fps: jint,
) -> JString<'l> {
    let v = jstr(&mut env, &version);
    env.new_string(easter_egg(taps as u32, &v, fps as u32).unwrap_or("")).unwrap()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn eggs() {
        assert_eq!(easter_egg(7, "26.1", 0), Some("Meow mode unlocked."));
        assert!(easter_egg(1, "26.1", 0).is_none());
    }
    #[test] fn fps_profile_merges() {
        let d = std::env::temp_dir().join("mclite_test");
        fs::create_dir_all(&d).unwrap();
        fs::write(d.join("options.txt"), "lang:en_us\nmaxFps:30\n").unwrap();
        apply_fps_profile(&d, 100).unwrap();
        let s = fs::read_to_string(d.join("options.txt")).unwrap();
        assert!(s.contains("lang:en_us") && s.contains("maxFps:100") && !s.contains("maxFps:30"));
    }
}
