# MC Lite 🐱

Minecraft Java Edition launcher scaffold for Android (arm64). Rust core (`src/lib.rs`) + Jetpack Compose UI. Pink/purple cat theme, by Ahmed.

## GitHub Actions build

This fixed ZIP is arranged for a GitHub repository like this:

```text
.github/workflows/build.yml   # workflow must be at repository root
mclite/                       # Android + Rust project files
```

Upload both `.github/` and `mclite/` from this ZIP into the repository root. The workflow automatically detects the `mclite/` project folder, runs the Rust tests, installs the Android SDK/NDK, compiles `libmclite.so` for `arm64-v8a`, and builds the debug APK. It also works if you later move the project files directly into the repository root.

To build, open **Actions** and run **Build MC Lite APK**, or push to `main`. After a successful run, download `mclite-debug-apk` from the workflow run's **Artifacts** section. Pushing a tag such as `v0.1` also publishes the APK as a GitHub Release.

## Included in this scaffold

- Reads Mojang's version manifest.
- Downloads and SHA1-verifies the client JAR, libraries and assets.
- Builds a JVM command line using the Java version in the version metadata.
- Writes a low-settings FPS profile to `options.txt`.
- Easter eggs: tap the cat 3 / 5 / 7 / 17 times.

## Still needed before this can launch Minecraft

1. An Android-compatible Java runtime for the required Minecraft Java version, plus code to start it.
2. ARM64 LWJGL natives and a compatible OpenGL translation layer (for example gl4es, ANGLE or Zink).
3. Microsoft account authentication. A valid purchased Minecraft account is required to play.
4. Native-library extraction, resumable downloads and a full version-selection UI.

## About the 100-FPS profile

The profile only changes game settings; it does not guarantee 100 FPS. Actual performance depends on the phone, Java runtime, renderer and Minecraft version.
