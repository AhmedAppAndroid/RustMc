//! Starts a real JVM inside the app process through libjli.so
//! (the same approach PojavLauncher uses). Blocks until the game exits.
use jni::{objects::{JObject, JString}, JNIEnv};
use std::{ffi::{c_char, c_int, c_void, CString}, fs::File, os::fd::AsRawFd};

extern "C" {
    fn dlopen(path: *const c_char, flags: c_int) -> *mut c_void;
    fn dlsym(handle: *mut c_void, name: *const c_char) -> *mut c_void;
    fn setenv(k: *const c_char, v: *const c_char, o: c_int) -> c_int;
    fn chdir(p: *const c_char) -> c_int;
    fn dup2(a: c_int, b: c_int) -> c_int;
}

type JliLaunch = unsafe extern "C" fn(
    c_int, *const *const c_char, c_int, *const *const c_char, c_int, *const *const c_char,
    *const c_char, *const c_char, *const c_char, *const c_char, u8, u8, u8, c_int,
) -> c_int;

fn c(s: &str) -> CString { CString::new(s).unwrap_or_default() }

/// args = JVM flags, main class, game args (what `prepare` returns after the first line).
pub fn run(java_home: &str, game_dir: &str, args: &[String]) -> Result<i32, String> {
    unsafe {
        let lib = format!("{java_home}/lib");
        setenv(c("JAVA_HOME").as_ptr(), c(java_home).as_ptr(), 1);
        setenv(c("LD_LIBRARY_PATH").as_ptr(), c(&format!("{lib}:{lib}/server")).as_ptr(), 1);
        chdir(c(game_dir).as_ptr());
        // Game output goes to latestlog.txt so we can see why it stops.
        if let Ok(f) = File::create(format!("{game_dir}/latestlog.txt")) {
            dup2(f.as_raw_fd(), 1);
            dup2(f.as_raw_fd(), 2);
        }
        dlopen(c(&format!("{lib}/server/libjvm.so")).as_ptr(), 0x102); // RTLD_NOW | RTLD_GLOBAL
        let h = dlopen(c(&format!("{lib}/libjli.so")).as_ptr(), 0x102);
        if h.is_null() { return Err(format!("cannot load {lib}/libjli.so")); }
        let sym = dlsym(h, c("JLI_Launch").as_ptr());
        if sym.is_null() { return Err("JLI_Launch not found".into()); }
        let launch: JliLaunch = std::mem::transmute(sym);

        let mut full = vec![c("java")];
        full.extend(args.iter().map(|a| c(a)));
        let ptrs: Vec<*const c_char> = full.iter().map(|s| s.as_ptr()).collect();
        Ok(launch(
            ptrs.len() as c_int, ptrs.as_ptr(), 0, std::ptr::null(), 0, std::ptr::null(),
            c("1.8.0-internal").as_ptr(), c("1.8").as_ptr(), c("java").as_ptr(),
            c("openjdk").as_ptr(), 0, 1, 0, 1,
        ))
    }
}

fn s(env: &mut JNIEnv, j: &JString) -> String {
    env.get_string(j).map(|x| x.into()).unwrap_or_default()
}

#[no_mangle]
pub extern "system" fn Java_dev_catos_mclite_Core_launch<'l>(
    mut env: JNIEnv<'l>, _this: JObject<'l>,
    home: JString<'l>, dir: JString<'l>, args: JString<'l>,
) -> JString<'l> {
    let (h, d, a) = (s(&mut env, &home), s(&mut env, &dir), s(&mut env, &args));
    let list: Vec<String> = a.lines().map(String::from).collect();
    let out = match run(&h, &d, &list) {
        Ok(code) => format!("Game exited with code {code}. See mc/latestlog.txt"),
        Err(e) => format!("ERR {e}"),
    };
    env.new_string(out).unwrap()
}
