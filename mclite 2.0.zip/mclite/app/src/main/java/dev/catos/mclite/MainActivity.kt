package dev.catos.mclite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

object Core {
    init { System.loadLibrary("mclite") }
    external fun prepare(version: String, root: String, name: String, uuid: String, token: String, fps: Int): String
    external fun egg(taps: Int, version: String, fps: Int): String
    external fun versions(): String
    external fun progress(): String
    external fun installRuntime(url: String, root: String): String
    external fun launch(javaHome: String, gameDir: String, args: String): String
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Home() } }
    }
}

private val Pink = Color(0xFFFF5FA2)

@Composable
private fun Card(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(20.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), content = content,
    )
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("mclite", 0) }
    val root = ctx.filesDir.path + "/mc"
    val scope = rememberCoroutineScope()
    var versions by remember { mutableStateOf(listOf("26.3", "26.1")) }
    var version by remember { mutableStateOf("26.1") }
    var fps by remember { mutableIntStateOf(100) }
    var taps by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var prog by remember { mutableFloatStateOf(0f) }
    var url by remember { mutableStateOf(prefs.getString("rt", "") ?: "") }
    val pulse by rememberInfiniteTransition(label = "p")
        .animateFloat(1f, 1.07f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s")

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val out = Core.versions()
            if (!out.startsWith("ERR") && out.isNotBlank()) versions = out.lines().filter { it.isNotBlank() }
        }
    }
    LaunchedEffect(busy) {
        while (busy) {
            val (d, t) = Core.progress().split("/").map { it.toFloatOrNull() ?: 0f }
            prog = if (t > 0f) d / t else 0f
            delay(300)
        }
    }

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF140A24), Color(0xFF3A1070))))
            .verticalScroll(rememberScrollState()).statusBarsPadding().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("🐱", fontSize = 64.sp, modifier = Modifier.scale(pulse).clickable {
            taps++; msg = Core.egg(taps, version, fps)
        })
        Text("MC Lite 2.0", fontSize = 30.sp, color = Color.White)
        Text("Minecraft Java · Rust core", color = Pink)

        Card {
            Text("Version", color = Color.White)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(versions) { v ->
                    FilterChip(version == v, { version = v; msg = Core.egg(taps, v, fps) }, { Text(v) })
                }
            }
            Text("Boost", color = Color.White)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 60, 100).forEach { f ->
                    FilterChip(fps == f, { fps = f; msg = Core.egg(taps, version, f) },
                        { Text(if (f == 0) "Off" else "$f FPS") })
                }
            }
        }

        Card {
            Text("Java runtime (Android arm64 .tar.xz)", color = Color.White)
            OutlinedTextField(url, { url = it }, singleLine = true, label = { Text("Runtime URL") },
                modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = {
                if (!busy) scope.launch(Dispatchers.IO) {
                    busy = true; msg = "Installing runtime…"
                    prefs.edit().putString("rt", url).apply()
                    val r = Core.installRuntime(url.trim(), "$root/runtime")
                    val jvm = File("$root/runtime").walkTopDown().maxDepth(6)
                        .filter { it.name == "libjvm.so" }.joinToString("\n")
                    msg = if (r == "OK") "Runtime installed.\n$jvm" else r.lines().getOrElse(1) { "error" }
                    busy = false
                }
            }) { Text("Install runtime") }
        }

        if (busy) LinearProgressIndicator(progress = { prog }, color = Pink, modifier = Modifier.fillMaxWidth())
        if (msg.isNotEmpty()) Text(msg, color = Pink)

        Button(
            onClick = {
                if (!busy) scope.launch(Dispatchers.IO) {
                    busy = true; msg = "Downloading $version…"
                    // TODO: Microsoft login supplies name/uuid/token.
                    val out = Core.prepare(version, root, "", "", "", fps).lines()
                    if (out[0] == "ERR") msg = out.getOrElse(1) { "error" } else {
                        val args = out.drop(1).joinToString("\n")
                        File(root, "launch.txt").writeText(args)
                        val jvm = File("$root/runtime").walkTopDown().maxDepth(6)
                            .firstOrNull { it.name == "libjvm.so" }
                        if (jvm == null) msg = "Files ready. Needs Java ${out[0]}: install the runtime first."
                        else {
                            msg = "Starting Minecraft…"
                            msg = Core.launch(jvm.parentFile!!.parentFile!!.parentFile!!.path, root, args)
                        }
                    }
                    busy = false
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Pink),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth().height(56.dp),
        ) { Text("PLAY", fontSize = 18.sp) }
        Text("by Ahmed", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
    }
}
