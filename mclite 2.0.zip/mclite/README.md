# MC Lite 🐱

Minecraft Java Edition launcher for low-end Android phones (target: Itel A70).
Rust core (`src/lib.rs`) + thin Jetpack Compose UI. Pink/purple cat theme, by Ahmed.

## Done in this scaffold
- Reads Mojang's manifest, so 26.1, 26.3 and anything newer just work
- Downloads and SHA1-verifies the client jar, libraries and assets
- Builds the JVM command line, with the Java version taken from the version JSON
- "100 FPS" profile: writes options.txt (render distance 4, no vsync, low particles) and low-memory JVM flags
- Easter eggs: tap the cat 3 / 5 / 7 / 17 times (some depend on version or FPS profile)
- Gradle project + GitHub Actions: tests, builds `libmclite.so` for arm64, builds the debug APK, attaches it to a release when you push a tag like `v0.1`

## Still needed (the hard parts)
1. Android-built JRE for the Java version each release needs, plus a way to start it
2. arm64 LWJGL natives and an OpenGL layer (gl4es / ANGLE / Zink). This decides real FPS
3. Microsoft login. Real Minecraft needs a purchased account
4. Natives extraction, resume downloads, version list UI

## About 100 FPS
Not guaranteed on an A70. Expect it in Superflat with low render distance and a fast GL layer. Vanilla 26.x with defaults will be well below. Measure on the phone and tune `apply_fps_profile` and `jvm_flags`.

## 2.0
- Live version list from Mojang, download progress bar, card-style UI
- Runtime installer: paste the URL of an Android arm64 JRE `.tar.xz`; the app unpacks it and shows where `libjvm.so` is
- Saves the full launch command to `launch.txt`
- Next (2.1): start the JVM from Rust once the runtime layout is known
